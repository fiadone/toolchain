/**
 * @module SmoothScroll
 * @package @fiad/toolbox
 * @description A smooth scroll handler
 */

import Component from '@fiad/toolbox/component'
import EventsManager from '@fiad/toolbox/events'
import { lerp } from '@fiad/toolbox/math'
import gsap from 'gsap'

class SmoothScroll extends Component {
  /**
   * Defaults options
   * @static
   * @type {object}
   */
  static defaults = {
    inertia = 0.2,
    layout = {
      wrapper: '[data-scroll-wrapper]',
      content: '[data-scroll-content]',
      items: '[data-scroll-item]'
    }
  }

  /**
   * @constructor
   * @param {(HTMLElement|null)} root 
   * @param {(object|null)} props 
   */
  constructor(props = {}) {
    super(document.body, { ...ScrollManager.defaults, ...props })

    this.y = window.scrollY
    this.init()
  }

  /**
   * Scroll target element(s) getter
   */
  get target() {
    return this.layout.items
      ? this.layout.items.filter(el => el.inViewport())
      : this.layout.content
  }

  /**
   * Root element height setter
   */
  setRootHeight = () => {
    const { content } = this.layout
    gsap.set(this.root, { height: content.clientHeight })
  }

  /**
   * Scroll event handler
   */
  onScroll = () => {
    this.y = lerp(this.y, window.scrollY, this.inertia)
  }

  /**
   * Request animation frame handler
   */
  requestScrollFrame = () => gsap.set(this.target, { y: -this.y })

  /**
   * Initializes component
   */
  init() {
    const { container, content } = this.layout
    
    if (container && content) {
      this.enabled = true
      this.setRootHeight()

      gsap.set(container, {
        width: '100%',
        height: '100%',
        position: 'fixed',
        top: 0,
        left: 0
      })

      EventsManager.on('resize', window, this.setRootHeight, { debounce: 200 })
      EventsManager.on('scroll', window, this.onScroll)
      gsap.ticker.add(this.requestScrollFrame)
    }
  }

  /**
   * Destroys component
   */
  destroy() {
    super.destroy()

    if (this.enabled) {
      EventsManager.off('resize', window, this.setRootHeight)
      EventsManager.off('scroll', window, this.onScroll)
  
      gsap.ticker.remove(this.requestScrollFrame)
      gsap.set(this.root, { clearProps: 'height' })
      gsap.set(this.layout.container, { clearProps: 'width, height, position, top, left' })
      gsap.set(this.target, { clearProps: 'x, y' })
    }
  }
}

/**
 * Exporting as singleton
 */
let instance = null

export default {
  enable: options => {
    if (!instance) {
      instance = new SmoothScroll(options)
    }
  },
  disable: () => {
    if (instance) {
      instance.destroy()
      instance = null
    }
  }
}
