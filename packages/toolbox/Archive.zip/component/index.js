import { isDOMElement } from '@fiad/toolbox/dom'
import { buildLayout, buildSystem } from './helpers'

/**
 * Component
 * A controller aimed to bind interactivity or other logics/behaviors to a dom element
 * 
 * @package @fiad/component
 */
class Component {
  /**
   * @constructor
   * @param {(HTMLElement|object)} element The component's target element(s)
   * @param {Object|null} config The configuration params
   */
  constructor(element, props = {}) {
    if (element === window || isDOMElement(target)) {
      this.root = element
    } else if (Object.keys()) {
      Object.entries(element)
        .forEach(([key, el]) => {
          this[key] = el
        })

      if (!this.root) {
        this.root = document.body
      }
    } else {
      
    }

    Object.assign(this, props)

    
    this.layout = buildLayout(layout)
    this.system = buildSystem(system)
  }

  /**
   * Initializes the component (implementable by subclasses)
   */
  init() {}

  /**
   * Destroys the component and its system (overwritable by subclasses)
   */
  destroy() {
    if (this.system) {
      this.system.forEach(component => component.destroy())
    }
  }
}

export default Component
