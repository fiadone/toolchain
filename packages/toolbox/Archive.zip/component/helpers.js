import { getAll } from '@fiad/toolbox/dom'

/**
 * Cyclically build component layout elements
 * 
 * @param {Component} instance The component instance
 * @param {Object} selectors The elements selectors list
 */
export function buildLayout(selectors = {}) {
  return Object.entries(selectors).reduce((acc, [ key, selector ]) => {
    if (acc.hasOwnProperty(key)) {
      console.warn(`An element with "${key}" key already exists`)
    } else {
      const elements = getAll(selector, instance.root)

      if (!elements.length) {
        console.warn(`No elements found for selector "${selector}"`)
      } else {
        acc[key] = elements.length > 1 ? elements : elements[0]
      }
    }

    return acc
  }, {})
}

/**
 * Cyclically builds sub-components
 * 
 * @param {Component} instance The component instance
 * @param {Object} system The sub-components list
 */
export function buildSystem(system = {}) {
  return Object.entries(system).reduce((acc, [ key, config ]) => {
    if (acc.hasOwnProperty(key)) {
      console.warn(`A sub-component with "${key}" key already exists`)
    } else {
      const Module = config.type
      const roots = getAll(config.selector, instance.root)

      if (!roots.length) {
        console.warn(`No elements found for selector "${config.selector}"`)
      } else {
        acc[key] = roots.length > 1
          ? roots.map(root => new Module(root, config.props))
          : new Module(roots[0], config.props)
      }
    }

    return acc
  }, {})
}